﻿CKEDITOR.plugins.add('HelloWorld', {
    init: function (editor) {
        var pluginName = 'HelloWorld';
        CKEDITOR.dialog.add(pluginName, this.path + 'dialogs/HelloWorld.js');
        editor.addCommand(pluginName, new CKEDITOR.dialogCommand(pluginName));
        editor.ui.addButton(pluginName,
        {
            label: 'Hello',
            command: pluginName,
            icon: this.path + 'images/hello.png'
        });
    }
});