CKEDITOR.plugins.setLang('vimeo', 'en',
{
  vimeo : 
  {
    title : "Embed Vimeo Video",
    button : "Embed Video",
    pasteMsg : "Please copy and paste the Youtube URL here"
  }
});